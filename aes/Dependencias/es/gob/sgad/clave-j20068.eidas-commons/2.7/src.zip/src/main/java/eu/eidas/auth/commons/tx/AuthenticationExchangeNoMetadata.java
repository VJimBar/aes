package eu.eidas.auth.commons.tx;

import javax.annotation.Nonnull;

import eu.eidas.auth.commons.protocol.IAuthenticationResponseNoMetadata;
import eu.eidas.util.Preconditions;

/**
 * The Authentication Exchange is composed of the node's authentication request and the final response from
 * the node, without Metadata.
 *
 * @since 1.1
 */
public final class AuthenticationExchangeNoMetadata {

    @Nonnull
    private final StoredAuthenticationRequestNoMetadata storedRequest;

    @Nonnull
    private final IAuthenticationResponseNoMetadata connectorResponse;

    public AuthenticationExchangeNoMetadata(@Nonnull StoredAuthenticationRequestNoMetadata storedRequest,
                                  @Nonnull IAuthenticationResponseNoMetadata connectorResponse) {
        Preconditions.checkNotNull(storedRequest, "storedRequest");
        Preconditions.checkNotNull(connectorResponse, "connectorResponse");
        this.storedRequest = storedRequest;
        this.connectorResponse = connectorResponse;
    }

    @Nonnull
    public StoredAuthenticationRequestNoMetadata getStoredRequest() {
        return storedRequest;
    }

    @Nonnull
    public IAuthenticationResponseNoMetadata getConnectorResponse() {
        return connectorResponse;
    }
}
