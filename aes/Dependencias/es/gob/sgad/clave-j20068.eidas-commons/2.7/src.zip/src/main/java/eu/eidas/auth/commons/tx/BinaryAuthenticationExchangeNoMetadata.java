package eu.eidas.auth.commons.tx;

import javax.annotation.Nonnull;

import eu.eidas.auth.commons.protocol.IResponseMessageNoMetadata;
import eu.eidas.util.Preconditions;

/**
 * The Authentication Exchange is composed of the original request from the ServiceProvider and the final response from
 * the Connector.
 *
 * @since 1.1
 */
public final class BinaryAuthenticationExchangeNoMetadata {

	@Nonnull
    private final StoredAuthenticationRequestNoMetadata storedRequest;

    @Nonnull
    private final IResponseMessageNoMetadata connectorResponseMessage;

    public BinaryAuthenticationExchangeNoMetadata(@Nonnull StoredAuthenticationRequestNoMetadata storedRequest,
                                        @Nonnull IResponseMessageNoMetadata connectorResponseMessage) {
        Preconditions.checkNotNull(storedRequest, "storedRequest");
        Preconditions.checkNotNull(connectorResponseMessage, "connectorResponseMessage");
        this.storedRequest = storedRequest;
        this.connectorResponseMessage = connectorResponseMessage;
    }

    @Nonnull
    public StoredAuthenticationRequestNoMetadata getStoredRequest() {
        return storedRequest;
    }

    @Nonnull
    public IResponseMessageNoMetadata getConnectorResponseMessage() {
        return connectorResponseMessage;
    }
}
