/**
 * Package for eIDAS Exceptions handling.
 * 
 * @since 1.0
 */
package eu.eidas.auth.commons.exceptions;

