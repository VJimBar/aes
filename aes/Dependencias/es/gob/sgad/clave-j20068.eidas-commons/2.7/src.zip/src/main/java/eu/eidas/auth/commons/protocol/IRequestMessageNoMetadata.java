package eu.eidas.auth.commons.protocol;

import javax.annotation.Nonnull;

/**
 * Request Message which contains the binary representation of the protocol request.
 *
 * @since 1.1
 */
public interface IRequestMessageNoMetadata extends IProtocolMessage {

    @Nonnull
    IAuthenticationRequestNoMetadata getRequest();
}
