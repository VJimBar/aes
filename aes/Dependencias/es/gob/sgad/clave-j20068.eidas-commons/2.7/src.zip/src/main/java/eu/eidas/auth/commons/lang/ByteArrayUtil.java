package eu.eidas.auth.commons.lang;

/**
 * ByteArrayUtil
 *
 * @since 1.1
 */
public final class ByteArrayUtil {

    public static final byte[] EMPTY = {};

    private ByteArrayUtil() {
    }
}
