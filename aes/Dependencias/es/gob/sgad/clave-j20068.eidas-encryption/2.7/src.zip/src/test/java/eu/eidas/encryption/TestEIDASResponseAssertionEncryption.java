package eu.eidas.encryption;


import org.junit.Test;

/**
 * Created by bodabel on 28/11/2014.
 */
public class TestEIDASResponseAssertionEncryption {
//class moved to EIDAS-SAMLEngine module in order to remove dependencies on duplicate classes under test/java/eu.eidas.auth.engine.core
    @Test
    public void testMethodIsMoved(){

    }
}
