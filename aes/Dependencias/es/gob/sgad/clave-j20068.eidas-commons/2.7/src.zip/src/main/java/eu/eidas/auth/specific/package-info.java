/**
 * Specific eIDAS Node Interfaces that implements functionality of the Authentication
 * Service.
 * 
 * @since 1.0
 */
package eu.eidas.auth.specific;

